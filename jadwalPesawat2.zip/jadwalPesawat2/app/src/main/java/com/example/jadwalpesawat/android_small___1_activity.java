
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		android_small___1
	 *	@date 		Friday 17th of March 2023 03:37:38 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class android_small___1_activity extends Activity {

	
	private View _bg__android_small___1_ek2;
	private View rectangle_1;
	private ImageView vector;
	private ImageView vector_ek1;
	private TextView hiling_id;
	private View rectangle_2;
	private TextView tanggal_keberangkatan;
	private TextView lokasi_tujuan;
	private TextView copyright_azka_hafidz_asianto_120140201;
	private TextView lokasi_keberangkatan;
	private View rectangle_3;
	private TextView cari;
	private View rectangle_4;
	private View rectangle_5;
	private View rectangle_6;
	private ImageView __img___material_symbols_calendar_month;
	private ImageView vector_ek2;
	private ImageView vector_ek3;
	private TextView masukkan_lokasi_keberangkatan;
	private TextView masukkan_lokasi_tujuan;
	private TextView masukkan_tanggal_keberangkatan;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.android_small___1);

		
		_bg__android_small___1_ek2 = (View) findViewById(R.id._bg__android_small___1_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		hiling_id = (TextView) findViewById(R.id.hiling_id);
		rectangle_2 = (View) findViewById(R.id.rectangle_2);
		tanggal_keberangkatan = (TextView) findViewById(R.id.tanggal_keberangkatan);
		lokasi_tujuan = (TextView) findViewById(R.id.lokasi_tujuan);
		copyright_azka_hafidz_asianto_120140201 = (TextView) findViewById(R.id.copyright_azka_hafidz_asianto_120140201);
		lokasi_keberangkatan = (TextView) findViewById(R.id.lokasi_keberangkatan);
		rectangle_3 = (View) findViewById(R.id.rectangle_3);
		cari = (TextView) findViewById(R.id.cari);
		rectangle_4 = (View) findViewById(R.id.rectangle_4);
		rectangle_5 = (View) findViewById(R.id.rectangle_5);
		rectangle_6 = (View) findViewById(R.id.rectangle_6);
		__img___material_symbols_calendar_month = (ImageView) findViewById(R.id.__img___material_symbols_calendar_month);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		masukkan_lokasi_keberangkatan = (TextView) findViewById(R.id.masukkan_lokasi_keberangkatan);
		masukkan_lokasi_tujuan = (TextView) findViewById(R.id.masukkan_lokasi_tujuan);
		masukkan_tanggal_keberangkatan = (TextView) findViewById(R.id.masukkan_tanggal_keberangkatan);
	
		
		//custom code goes here
	
	}
}
	
	