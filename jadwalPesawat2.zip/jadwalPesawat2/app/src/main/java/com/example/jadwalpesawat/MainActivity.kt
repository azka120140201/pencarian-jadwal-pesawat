package com.example.jadwalpesawat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}data class Jadwal(val jadwal_id: Int, val bandara_kode_keberangkatan: String, val bandara_kode_tujuan: String, val maskapai_id: Int)
data class Maskapai(val maskapai_id: Int, val maskapai_nama: String, val maskapai_logo: String)
data class Bandara(val bandara_kode: String, val bandara_nama: String)