
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		android_small___2
	 *	@date 		Friday 17th of March 2023 03:46:05 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class android_small___2_activity extends Activity {

	
	private View _bg__android_small___2_ek2;
	private View rectangle_1;
	private ImageView vector;
	private ImageView vector_ek1;
	private TextView hiling_id;
	private TextView hasil_pencarian_penerbangan;
	private View rectangle_2;
	private ImageView vector_ek2;
	private TextView __l_keberangkatan_;
	private TextView __l_tujuan_;
	private TextView __tanggal_keberangkatan_;
	private TextView elang;
	private View rectangle_3;
	private ImageView vector_ek3;
	private TextView __l_keberangkatan__ek1;
	private TextView __l_tujuan__ek1;
	private TextView __tanggal_keberangkatan__ek1;
	private TextView tapis_air;
	private View rectangle_4;
	private ImageView vector_ek4;
	private TextView __l_keberangkatan__ek2;
	private TextView __l_tujuan__ek2;
	private TextView __tanggal_keberangkatan__ek2;
	private TextView majapahit_air;
	private TextView copyright_azka_hafidz_asianto_120140201;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.android_small___2);

		
		_bg__android_small___2_ek2 = (View) findViewById(R.id._bg__android_small___2_ek2);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		hiling_id = (TextView) findViewById(R.id.hiling_id);
		hasil_pencarian_penerbangan = (TextView) findViewById(R.id.hasil_pencarian_penerbangan);
		rectangle_2 = (View) findViewById(R.id.rectangle_2);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		__l_keberangkatan_ = (TextView) findViewById(R.id.__l_keberangkatan_);
		__l_tujuan_ = (TextView) findViewById(R.id.__l_tujuan_);
		__tanggal_keberangkatan_ = (TextView) findViewById(R.id.__tanggal_keberangkatan_);
		elang = (TextView) findViewById(R.id.elang);
		rectangle_3 = (View) findViewById(R.id.rectangle_3);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		__l_keberangkatan__ek1 = (TextView) findViewById(R.id.__l_keberangkatan__ek1);
		__l_tujuan__ek1 = (TextView) findViewById(R.id.__l_tujuan__ek1);
		__tanggal_keberangkatan__ek1 = (TextView) findViewById(R.id.__tanggal_keberangkatan__ek1);
		tapis_air = (TextView) findViewById(R.id.tapis_air);
		rectangle_4 = (View) findViewById(R.id.rectangle_4);
		vector_ek4 = (ImageView) findViewById(R.id.vector_ek4);
		__l_keberangkatan__ek2 = (TextView) findViewById(R.id.__l_keberangkatan__ek2);
		__l_tujuan__ek2 = (TextView) findViewById(R.id.__l_tujuan__ek2);
		__tanggal_keberangkatan__ek2 = (TextView) findViewById(R.id.__tanggal_keberangkatan__ek2);
		majapahit_air = (TextView) findViewById(R.id.majapahit_air);
		copyright_azka_hafidz_asianto_120140201 = (TextView) findViewById(R.id.copyright_azka_hafidz_asianto_120140201);
	
		
		//custom code goes here
	
	}
}
	
	